from enum import Enum

class Dir(Enum):
    NORTH = 0
    WEST = 1
    SOUTH = 2
    EAST = 3
